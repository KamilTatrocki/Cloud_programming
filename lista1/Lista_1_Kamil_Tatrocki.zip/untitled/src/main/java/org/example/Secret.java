package org.example;

public  class Secret {
    static public  String secret= "amqps://morhxyih:8QP_W3DEpk9rqnGbGEJ2_DxGyoY1UDRu@cow.rmq2.cloudamqp.com/morhxyih";
}
